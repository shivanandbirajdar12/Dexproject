import React, { useState } from 'react'
import swapbutton from '../Assets/images2/swapbutton1.png'

import PlusComponent from './PlusComponent'

const SwapComponent = (props) => {

    return (
        <div>
            <div id='swap-page' className='mt-3'>
                <div className='enpFfZ '>
                    <div className='iUsjHb mt-3 hhoFBL1 p-2 morphism' >
                        <div className='d-flex' style={{ gap: '0 130px' }} >
                            <div className='hhoFBL p-2'>
                                <p className="m-0 text-light ms-2">You pay</p>
                                <input
                                    type="text"

                                    className="currency-input"
                                    placeholder="0"
                                />
                            </div>
                            <div className='text-light d-flex flex-column align-item-center justify-content-center'>
                                <button className="max-parent max-parent-swap my-0">
                                    <p className="max my-0">MAX</p>
                                </button>
                            </div>
                        </div>
                        <div className='me-2 mt-2'>
                            <button className="we" type="button" >
                                <img
                                    src="./images/sprint.png"
                                    height="23px"
                                    width="23px"
                                    alt=""
                                />
                                <span className="text-light ms-2">ETH</span>
                                <img
                                    src="/images/dropdown.png"
                                    height="23px"
                                    width="23px"
                                    alt=""
                                />
                            </button>
                            <p className="ms-4 mt-2 mb-0 text-light ">balance: 0</p>
                        </div>
                    </div>
                    <PlusComponent img={swapbutton} />
                    <div className='iUsjHb morphism hhoFBL1 p-2 ' id='swapbottom' >
                        <div className='d-flex' style={{ gap: '0 130px' }} >
                            <div className='hhoFBL p-2'>
                                <p className="m-0 text-light ms-2">You pay</p>
                                <input
                                    type="text"
                                    className="currency-input"
                                    placeholder="0"
                                />
                            </div>
                            <div className='text-light d-flex flex-column align-item-center justify-content-center'>
                                <button className="max-parent max-parent-swap my-0">
                                    <p className="max my-0">MAX</p>
                                </button>
                            </div>
                        </div>
                        <div className='me-2 mt-2'>
                            <button className="ws" type="button"  >
                                <span className="text-light ms-2">Select Token</span>
                                <img
                                    src="/images/dropdown.png"
                                    height="23px"
                                    width="23px"
                                    alt=""
                                />
                            </button>
                            <p className="ms-4 mt-2 mb-0 text-light">balance: 0</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default SwapComponent
