import React from 'react'
import LiquidityReward from '../PoolContent/LiquidityReward'
import CreatePair from '../PoolContent/CreatePair'
import ImportPool from '../PoolContent/ImportPool'
import AddLiquidty from '../PoolContent/AddLiquidty'
import MyNavbar from './MyNavbar'



const Pool = () => {
  return (
    <div>
      <MyNavbar/>
      <LiquidityReward/>
      {/* <CreatePair/>
      <ImportPool/>
      <AddLiquidty/> */}
      
    </div>
  )
}

export default Pool
