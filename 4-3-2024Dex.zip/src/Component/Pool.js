import React from 'react'
import LiquidityReward from '../PoolContent/LiquidityReward'
import MyNavbar from './MyNavbar'



const Pool = () => {
  return (
    <div>
      <MyNavbar/>
      <LiquidityReward/>
     
      
    </div>
  )
}

export default Pool
