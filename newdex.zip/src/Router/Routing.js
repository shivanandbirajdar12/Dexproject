import Swap from '../Component/Swap';
function Main() {
  return (
    <>
    <Swap/>
    </>
  );
}

export default Main;