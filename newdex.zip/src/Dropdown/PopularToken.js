import React from 'react'

const PopularToken = (props) => {
    return (
        <>
            <div className='cPCYrp dKubqp bIFEzi cFvOnL'>
                <div className='bFCsHr'>
                    <img src="./images/sprint.png" style={{ height: "34px", width: '34px' }} alt='' />
                </div>
                <div className='eENUcJ'>
                    <div className='dKubqp dKubqptext cPCYrp '>{props.option}</div>
                    <div className='css-1m0dqmt  jgbRhf'>1inch</div>
                </div>
            </div>
        </>
    )
}

export default PopularToken
