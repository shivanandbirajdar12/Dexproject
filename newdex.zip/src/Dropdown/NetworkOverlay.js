// import React, { useState, useEffect, useRef } from 'react';
// import './network.css';
// import group1 from '../Assets/images2/Layer_x0020_1.png';
// import tennisicon from '../Assets/images2/teenyicons_tick-solid.png';

// const NetworkOverlay = () => {
//     const [isOpen, setIsOpen] = useState(false);
//     const dropdownRef = useRef(null);
//     const networkOverlayRef = useRef(null);

//     const toggleDropdown = () => {
//         setIsOpen(!isOpen);
//     };

//     useEffect(() => {
//         function handleClickOutside(event) {
//             if (
//                 isOpen &&
//                 networkOverlayRef.current &&
//                 !networkOverlayRef.current.contains(event.target)
//             ) {
//                 setIsOpen(false);
//             }
//         }

//         document.addEventListener('mousedown', handleClickOutside);
//         return () => {
//             document.removeEventListener('mousedown', handleClickOutside);
//         };
//     }, [isOpen]);

//     const imageStyles = {
//         height: '23px',
//         width: '23px',
//     };

//     return (
//         <>
//             <button
//                 id="selectedOptionBtn"
//                 ref={networkOverlayRef}
//                 type="button"
//                 className="btnGroupDrop1"
//                 onClick={toggleDropdown}
//             >
//                 <img
//                     src="/images/sprint.png"
//                     className="ms-2"
//                     style={imageStyles}
//                     alt=""
//                 />
//                 <img
//                     src="/images/dropdown.png"
//                     className={`icons ${isOpen ? 'rotated' : ''}`}
//                     alt=""
//                     style={imageStyles}
//                 />
//             </button>

//             {isOpen && (
//                 <div className="network-overlay" ref={dropdownRef}>
//                     <div className="network-overlay-inner">
//                         <div className="networks-parent">
//                             <img className="networks-icon" alt="" src={group1} />
//                             <div className="ethereum">Ethereum</div>
//                         </div>
//                         <img
//                             className="teenyiconstick-solid"
//                             alt=""
//                             src={tennisicon}
//                         />
//                     </div>
//                     <div className="network-overlay-inner">
//                         <div className="networks-parent">
//                             <img className="networks-icon1" alt="" src="NETWORKS.svg" />
//                             <div className="ethereum">Arbitrum</div>
//                         </div>
//                     </div>
//                     <div className="network-overlay-inner">
//                         <div className="networks-parent">
//                             <img className="networks-icon" alt="" src="NETWORKS.svg" />
//                             <div className="ethereum">Optimism</div>
//                         </div>
//                     </div>
//                     <div className="network-overlay-inner">
//                         <div className="networks-parent">
//                             <img className="networks-icon" alt="" src="NETWORKS.svg" />
//                             <div className="ethereum">Polygon</div>
//                         </div>
//                     </div>
//                     <div className="network-overlay-inner">
//                         <div className="networks-parent">
//                             <img className="networks-icon" alt="" src="NETWORKS.svg" />
//                             <div className="ethereum">BNB Chain</div>
//                         </div>
//                     </div>
//                     <div className="network-overlay-inner">
//                         <div className="networks-parent">
//                             <img className="networks-icon" alt="" src="NETWORKS.svg" />
//                             <div className="ethereum">Avalanche</div>
//                         </div>
//                     </div>
//                 </div>
//             )}
//         </>
//     );
// };

// export default NetworkOverlay;
import React, { useState, useEffect, useRef } from 'react';
import './network.css';
import group1 from '../Assets/images2/Layer_x0020_1.png';
import group2 from '../Assets/images2/Group (1).png';
import tennisicon from '../Assets/images2/teenyicons_tick-solid.png';

const NetworkOverlay = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [selectedNetwork, setSelectedNetwork] = useState({ name: 'Ethereum', icon: group1 });
    const dropdownRef = useRef(null);
    const networkOverlayRef = useRef(null);

    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    const selectNetwork = (networkName, networkIcon) => {
        setSelectedNetwork({ name: networkName, icon: networkIcon });
        setIsOpen(false);
    };

    useEffect(() => {
        function handleClickOutside(event) {
            if (
                isOpen &&
                networkOverlayRef.current &&
                !networkOverlayRef.current.contains(event.target)
            ) {
                setIsOpen(false);
            }
        }

        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, [isOpen]);

    const imageStyles = {
        height: '23px',
        width: '23px',
    };

    return (
        <>
            <button
                id="selectedOptionBtn"
                ref={networkOverlayRef}
                type="button"
                className="btnGroupDrop1"
                onClick={toggleDropdown}
            >
                {selectedNetwork.icon && (
                    <img src={selectedNetwork.icon} className="ms-2 networks-icon" alt="" style={imageStyles} />
                )}
                <img
                    src="/images/dropdown.png"
                    className={`icons ${isOpen ? 'rotated' : ''}`}
                    alt=""
                    style={imageStyles}
                />
            </button>

            {isOpen && (
                <div className="network-overlay" ref={dropdownRef}>
                    <div className="network-overlay-inner" onClick={() => selectNetwork('Ethereum', group1)}>
                        <div className="networks-parent">
                            <img className="networks-icon" alt="" src={group1} />
                            <div className="ethereum">Ethereum</div>
                        </div>
                        {selectedNetwork.name === 'Ethereum' && (
                            <img className="teenyiconstick-solid" alt="" src={tennisicon} />
                        )}
                    </div>
                    <div className="network-overlay-inner" onClick={() => selectNetwork('Arbitrum', group2)}>
                        <div className="networks-parent">
                            <img className="networks-icon" alt="" src={group2} />
                            <div className="ethereum">Arbitrum</div>
                        </div>
                        {selectedNetwork.name === 'Arbitrum' && (
                            <img className="teenyiconstick-solid" alt="" src={tennisicon} />
                        )}
                    </div>
                </div>
            )}
        </>
    );
};

export default NetworkOverlay;
