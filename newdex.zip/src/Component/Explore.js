import React, { useState } from 'react';
import { Tab, Nav } from 'react-bootstrap';
import TokenTable from '../ExploreContent/Tokentable';
import Pooltable from '../ExploreContent/Pooltable';
import Transactionstable from '../ExploreContent/Transactionstable';
import '../Assets/CSS/tokens.css';
import Volume from '../Dropdown/Volume';
import MyNavbar from './MyNavbar';

const TableContent2 = () => {

    const [selectedTab, setSelectedTab] = useState('pills-home');
    const [isOpen5 ,setIsOpen5]= useState(false)
    const toggleDropdown5 = () => {
        setIsOpen5(!isOpen5);
      };


    const handleTabSelect = (key) => {
        setSelectedTab(key);
    };
    const [timeFrameClass, setTimeFrameClass] = useState({
        D: 'd-wrapper',
        W: 'w-wrapper',
        M: 'w-wrapper',
        Y: 'w-wrapper',
    });
    const handleTimeFrameClick = (timeFrame) => {
        const updatedClass = Object.fromEntries(
            Object.entries(timeFrameClass).map(([key, value]) => [key, key === timeFrame ? 'd-wrapper' : 'w-wrapper'])
        );

        setTimeFrameClass(updatedClass);
    };

    return (
        <>
           <MyNavbar/>
            {/* Graph section */}
            <div className="container glassmorphism rounded mt-3 " style={{borderRadius:'15px'}}>
                <div className="row px-3 " >
                    <div className="col-md-12 p-2 text-light " >
                        <div className="d-flex align-items-center justify-content-center">
                            <p className='w-100' style={{color:'#9b9797'}}>TrendSwap Volume</p>
                            <div className="parent-frame">
                            <button className={timeFrameClass.D} onClick={() => handleTimeFrameClick('D')}>
                                D
                            </button>
                            <button className={timeFrameClass.W} onClick={() => handleTimeFrameClick('W')}>
                                W
                            </button>
                            <button className={timeFrameClass.M}onClick={() => handleTimeFrameClick('M')}>
                                M
                            </button>
                            <button className={timeFrameClass.Y} onClick={() => handleTimeFrameClick('Y')}>
                                Y
                            </button>
                            </div>
                        </div>
                        <div className="million d-flex align-items-center justify-content-between">
                            <div >
                                <h2>$110.42B</h2>
                                <p style={{color:'#9b9797'}}>Past Month</p>
                            </div>
                        </div>
                        <div><img src="/images/updatedgrap.png" alt="" className="img-fluid" /></div>
                    </div>
                </div>
            </div>
            <div className="container">
                <Tab.Container id="pills-tab" defaultActiveKey={selectedTab} onSelect={handleTabSelect} >
                    <div className="table-tab d-flex justify-content-between mt-5">
                        <Nav variant="pills" className="mb-3" style={{ backgroundColor: 'transparent' }}>
                            <Nav.Item >
                                <Nav.Link eventKey="pills-home" className=' tabcolor'>Tokens</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                                <Nav.Link eventKey="pills-profile" className=' tabcolor'>Pools</Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                                <Nav.Link eventKey="pills-contact" className=' tabcolor'>Transactions</Nav.Link>
                            </Nav.Item>
                        </Nav>
                        <Tab.Content className=''>
                            <Tab.Pane eventKey="pills-home">

                                <button variant="primary" className="tab-button m-1">
                                    <img src="/images/sprint.png" height="23px" width="23px" alt="" />
                                    <img src="/images/dropdown.png" height="23px" width="23px" alt="" />
                                </button>
                                <button variant="primary" className="px-3 tab-button text-light m-1 " onClick={toggleDropdown5} >
                                    1D-volume
                                    <img src="/images/dropdown.png" height="23px" width="23px" alt="" />
                                </button>
                                {isOpen5 && <Volume />}
                                <a href=""><img src="/images/search.png" height="24px" width="24px" alt="" /></a>

                            </Tab.Pane>
                            <Tab.Pane eventKey="pills-profile">
                                <div className="tpt-buttons d-flex align-items-center justify-content-center">
                                    <button variant="primary" className="px-3 tab-button text-light m-1">
                                        <img src="/images/sprint.png" height="23px" width="23px" alt="" />
                                        <img src="/images/dropdown.png" height="23px" width="23px" alt="" />
                                    </button>
                                    <a href=""><img src="/images/search.png" height="24px" width="24px" alt="" /></a>
                                </div>
                            </Tab.Pane>
                            <Tab.Pane eventKey="pills-contact">
                                <div className="tpt-buttons d-flex align-items-center justify-content-center">
                                    <button variant="primary" className="px-3 tab-button text-light m-1">
                                        <img src="/images/sprint.png" height="23px" width="23px" alt="" />
                                        <img src="/images/dropdown.png" height="23px" width="23px" alt="" />
                                    </button>
                                </div>
                            </Tab.Pane>
                        </Tab.Content>
                    </div>
                </Tab.Container>
            </div>
            {selectedTab === 'pills-home' && <TokenTable />}
            {selectedTab === 'pills-profile' && <Pooltable />}
            {selectedTab === 'pills-contact' && <Transactionstable />}
        </>
    );
};

export default TableContent2;
