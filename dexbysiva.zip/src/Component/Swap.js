import React, { useState } from "react";
import "../Assets/CSS/nav.css";
// import settingimg from "../Assets/images2/settings.png";
import Setting from "../Dropdown/Setting";
import MyNavbar from "./MyNavbar";
const Home = () => {
  const [isConnected, setIsConnected] = useState(false);
  const [isOpen3, setIsOpen3] = useState(false);
  const handleConnectWallet = () => {
    setIsConnected(true);
  };

  const toggleDropdown3 = () => {
    setIsOpen3(!isOpen3);
  };

  return (
    <div>
      {/* <!-- ======================= Body section of Home page ================ --> */}
       <MyNavbar/>
      <div className="container">
        <div className="swap-anytime-anywhere-container mx-3">
          <p className="swap-anytime">Swap anytime,</p>
          <p className="swap-anytime">anywhere</p>
        </div>
        <div className="d-flex col-md-5 mx-auto mt-2  py-3 glassmorphism  align-items-center flex-column" style={{ border: " 1px solid #646464" }}>
          <div className="swapoption d-flex justify-content-between align-items-center">
                        <button className="swaptext">Swap</button>
                        <img src="/images/settings.png" style={{height:'20px', width:'20px'}} onClick={toggleDropdown3} alt="" />
                        {isOpen3 && <Setting />}
                    </div>
          <div className="pqrst morphism  d-flex justify-content-between align-item-center mt-1 col-4 mx-auto">
            <div className="d-flex justify-content-between p-2 align-item-center">
              <div
                className=" d-flex justify-content-center align-item-center "
                style={{ gap: "0px 40px" }}
              >
                <div className="d-flex justify-content-between align-item-center flex-column">
                  <p className="m-0  ms-2">You pay</p>
                  <input
                    type="text"
                    name=""
                    id="currency-input"
                    placeholder="0"
                  />
                  {/* <p className="m-0  ms-2">$</p> */}
                </div>
                <button className="max-parent max-parent-swap my-0">
                  <p className="max my-0">MAX</p>
                </button>
              </div>
            </div>
            <div
              className="d-flex justify-content-center  align-item-center flex-column"
              style={{ gap: "8px 0" }}
            >
              <button className="we" type="button" >
                <img
                  src="./images/sprint.png"
                  height="23px"
                  width="23px"
                  alt=""
                />
                <span className="text-light ms-2">ETH</span>
                <img
                  src="/images/dropdown.png"
                  height="23px"
                  width="23px"
                  alt=""
                />
              </button>
              <p className="ms-4 mt-2 mb-0">balance: 0</p>
            </div>
          </div>
          <div className="arrow-container  text-center">
            <button className="px-1 py-1 swap">
              <img
                src="/images/swap.png"
                className="p-1"
                height="22px"
                width="22px"
                alt=""
              />
            </button>
          </div>
          <div className="pqrst morphism d-flex justify-content-between align-item-center col-4 mx-auto" id="swapbottom">
            <div className="d-flex justify-content-between p-2 align-item-center">
              <div
                className=" d-flex justify-content-center align-item-center "
                style={{ gap: "0px 40px" }}
              >
                <div className="d-flex justify-content-between align-item-center flex-column">
                  <p className="m-0 ms-2">You recive</p>
                  <input
                    type="text"
                    name=""
                    id="currency-input"
                    placeholder="0"
                  />
                  {/* <p className="m-0  ms-2">$</p> */}
                </div>
                <button className="max-parent max-parent-swap my-0">
                  <p className="max my-0">MAX</p>
                </button>
              </div>
            </div>
            <div
              className="d-flex justify-content-center align-item-center flex-column"
              style={{ gap: "8px 0" }}
            >
              <button className="select-token-button" type="button">
                select token
                <span className="icons">
                  <img
                    src="/images/dropdown.png"
                    style={{ height: "24px", width: "24px" }}
                    alt=""
                  />
                </span>
              </button>
              <p className="ms-4 mt-2 mb-0">balance: 0</p>
            </div>
          </div>
          <div className="connect-button mt-2 " style={{ width: "100%" }} >
            <button
              className={`connect-wallet ${isConnected ? "transparent" : ""}`}
              onClick={handleConnectWallet}
            >
              {isConnected ? "Enter an amount" : "Connect Wallet"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default Home;