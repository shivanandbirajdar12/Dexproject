import { Routes, Route } from "react-router-dom";
import MyNavbar from '../Component/MyNavbar'
import Home from "../Component/Home";
import Swap from '../Component/Swap';
import Explore from '../Component/Explore';
import Analytics from '../Component/Analytics';
import Pool from "../Component/Pool";
function Main() {
  return (
    <>
    <MyNavbar/>
    <Home/>
   
    </>
  );
}

export default Main;