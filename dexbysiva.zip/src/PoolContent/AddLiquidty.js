import React from "react";
import pharrow from "../Assets/images2/ph_arrow-down.png";
import phquestion from "../Assets/images2/ph_question.png";
import plus from "../Assets/images2/tdesign_swap.png";
import { Link } from "react-router-dom";
import MyNavbar from "../Component/MyNavbar";


const AddLiquidty = () => {
  return (
    <>
    <MyNavbar/>
      <div className="d-flex col-md-4 col-sm-4 mx-auto mt-4  py-3 glassmorphism  align-items-center flex-column" style={{ border: " 1px solid #646464"}}>
        <div className="swapoption d-flex justify-content-between mt-3 align-items-center">
        <Link to='/pool'><img src={pharrow} style={{ height: "20px", width: "20px" }} alt="" /></Link>
          <button className="swaptext">Add Liquidity</button>
          <img
            src={phquestion}
            style={{ height: "20px", width: "20px" }}
            alt=""
          />
        </div>
        <div className="pqrst morphism d-flex justify-content-between align-item-center  col-4 mx-auto">
          <div className="d-flex justify-content-between p-2 align-item-center">
            <div
              className=" d-flex justify-content-center align-item-center "
              style={{ gap: "0px 40px" }}
            >
              <div className="d-flex justify-content-between align-item-center flex-column">
                <p className="m-0  ms-2">Input</p>
                <input
                  type="text"
                  name=""
                  id="currency-input"
                  placeholder="0"
                />
              </div>
              <button className="max-parent max-parent-create my-0">
                <p className="max my-0" >MAX</p>
              </button>
            </div>
          </div>
          <div
            className="d-flex justify-content-center  align-item-center flex-column"
            style={{ gap: "20px 0" }}
          >
            <button className="we" type="button">
              <img
                src="./images/sprint.png"
                height="23px"
                width="23px"
                alt=""
              />
              <span className="text-light ms-2">ETH</span>
              <img
                src="/images/dropdown.png"
                height="23px"
                width="23px"
                alt=""
              />
            </button>
            <p className="ms-4 mt-2 mb-0">balance: 0</p>
          </div>
        </div>
        <div className="arrow-container text-center " style={{zIndex:'999'}}>
          <button className="px-1 py-1   ">
            <img
              src={plus}
              className="p-1"
              height="48px"
              width="48px"
              alt=""
            />
          </button>
        </div>
        <div
          className="pqrst morphism d-flex justify-content-between align-item-center col-4 mx-auto"
          id="swapbottom1"
        >
          <div className="d-flex justify-content-between p-2 align-item-center">
            <div
              className=" d-flex justify-content-center align-item-center "
              style={{ gap: "0px 40px" }}
            >
              <div className="d-flex justify-content-between align-item-center flex-column">
                <p className="m-0 ms-2">Input</p>
                <input
                  type="text"
                  name=""
                  id="currency-input"
                  placeholder="0"
                />
              </div>
              <button className="max-parent max-parent-create my-0">
                <p className="max my-0">MAX</p>
              </button>
            </div>
          </div>
          <div
            className="d-flex justify-content-center align-item-center flex-column"
            style={{ gap: "20px 0" }}
          >
            <button className="select-token-button" type="button">
              select token
              <span className="icons">
                <img
                  src="/images/dropdown.png"
                  style={{ height: "24px", width: "24px" }}
                  alt=""
                />
              </span>
            </button>
            <p className="ms-4 mt-2 mb-0">balance: 0</p>
          </div>
        </div>
        <button className="invalid-pair morphism mt-2 mb-4 " style={{ width: "100%" }}>
          <p className="invalid-pair-text" >Enter an amount</p>
        </button>
      </div>
    </>
  );
};

export default AddLiquidty;
