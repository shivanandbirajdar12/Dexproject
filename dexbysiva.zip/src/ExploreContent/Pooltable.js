import React, { useState, useEffect } from 'react';
import { Table } from 'react-bootstrap';

const YourComponent = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Fetch data from your API and update the state
    // Replace 'yourApiEndpoint' with the actual endpoint
    fetch('yourApiEndpoint')
      .then(response => response.json())
      .then(data => setData(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  return (
    <div className="container mt-1 mb-5 p-0 table-responsive table-container" style={{ borderRadius: '15px' }}>
      <Table className="mb-0 p-5 text-light">
        <thead>
          <tr className="border-bottom thead-background">
            <th>#</th>
            <th>Pool</th>
            <th>Transactions</th>
            <th>1 Day Volume</th>
            <th>7 Day Volume</th>
            <th>TurnOver</th>
            <th>Graph</th>
          </tr>
        </thead>
        <tbody className='glassmorphism '>
          {data.map((item, index) => (
            <tr key={index}>
              <td>{index + 1}</td>
              <td>
                <img src={item.poolImage} className="tokenimg" alt="" />
                {item.poolDetails}<span className="ms-2 badge badges">{item.percentage}</span>
              </td>
              <td>{item.transactions}</td>
              <td>
                <img src="/images/down.png" className="tokenimg" alt="" /> {item.oneDayVolume}%
              </td>
              <td>{item.sevenDayVolume}</td>
              <td>{item.turnover}</td>
              <td>
                <img src="/images/downgraph.png" width="124px" height="24px" alt={`Graph ${index + 1}`} />
              </td>
            </tr>
          ))}
        </tbody>
      </Table>
    </div>
  );
};

export default YourComponent;
