// import React, { useState, useEffect } from 'react';
// import { Table } from 'react-bootstrap';


// const TokenTable = () => {
//   const [tokenData, setTokenData] = useState([]);

//   useEffect(() => {
// //   Change 'apiurl' with the actual API url for fetching token data
//     fetch('apiurl')
//       .then((response) => response.json())
//       .then((data) => setTokenData(data))
//       .catch((error) => console.error('Error fetching token data:', error));
//   }, []); 

//   return (
//     <div className="container mt-1 mb-5 p-0 table-responsive table-container" style={{ borderRadius: '15px' }}>
//       <Table className="table  mb-0 p-5"  id="pills-home">
//         <thead>
//           <tr className="border-bottom thead-background" >
//             <th>#</th>
//             <th>Token Name</th>
//             <th>Price</th>
//             <th>1 Hour</th>
//             <th>1 Day</th>
//             <th>FDV</th>
//             <th>
//               <img src="/images/volumearrow.png" alt="" style={{ height: '20px', width: '20px' }} />Volume
//             </th>
//             <th>Graph</th>
//           </tr>
//         </thead>
//         <tbody className='glassmorphism'>
//           {tokenData.map((token, index) => (
//             <tr key={index}>
//               <td>{token.rank}</td>
//               <td>
//                 <img src={token.image} className="tokenimg" alt="" /> {token.name} <span>{token.symbol}</span>
//               </td>
//               <td>${token.price}</td>
//               <td>
//                 <img src={token.hourChange > 0 ? "/images/up.png" : "/images/down.png"} className="tokenimg" alt="" /> {token.hourChange}%
//               </td>
//               <td>
//                 <img src={token.dayChange > 0 ? "/images/up.png" : "/images/down.png"} className="tokenimg" alt="" /> {token.dayChange}%
//               </td>
//               <td>${token.marketCap}</td>
//               <td>${token.volume}</td>
//               <td>
//                 <img src={token.graphImage} style={{ height: '24px', width: '124px' }} alt={`Graph ${index + 1}`} />
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </Table>
//     </div>
//   );
// };

// export default TokenTable;
import React, { useState, useEffect } from 'react';
import { useTable } from 'react-table';
import { Table } from 'react-bootstrap';

const TokenTable = () => {
  const [tokenData, setTokenData] = useState([]);

  useEffect(() => {
    // Change 'apiurl' with the actual API url for fetching token data
    fetch('apiurl')
      .then((response) => response.json())
      .then((data) => setTokenData(data))
      .catch((error) => console.error('Error fetching token data:', error));
  }, []);

  const columns = [
    {
      Header: '#',
      accessor: 'rank'
    },
    {
      Header: 'Token Name',
      accessor: 'name',
      Cell: ({ row }) => (
        <div>
          <img src={row.original.image} className="tokenimg" alt="" /> {row.original.name} <span>{row.original.symbol}</span>
        </div>
      )
    },
    {
      Header: 'Price',
      accessor: 'price',
      Cell: ({ value }) => `$${value}`
    },
    {
      Header: '1 Hour',
      accessor: 'hourChange',
      Cell: ({ value }) => (
        <div>
          <img src={value > 0 ? "/images/up.png" : "/images/down.png"} className="tokenimg" alt="" /> {value}%
        </div>
      )
    },
    {
      Header: '1 Day',
      accessor: 'dayChange',
      Cell: ({ value }) => (
        <div>
          <img src={value > 0 ? "/images/up.png" : "/images/down.png"} className="tokenimg" alt="" /> {value}%
        </div>
      )
    },
    {
      Header: 'FDV',
      accessor: 'marketCap',
      Cell: ({ value }) => `$${value}`
    },
    {
      Header: 'Volume',
      accessor: 'volume',
      Cell: ({ value }) => `$${value}`
    },
    {
      Header: 'Graph',
      accessor: 'graphImage',
      Cell: ({ value }) => <img src={value} style={{ height: '24px', width: '124px' }} alt="Graph" />
    }
  ];

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow
  } = useTable({ columns, data: tokenData });

  return (
    <div className="container mt-1 mb-5 p-0 table-responsive table-container" style={{ borderRadius: '15px' }}>
      <Table className="table   mb-0 p-5" id="pills-home" {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr className="border-bottom thead-background" {...headerGroup.getHeaderGroupProps()}>
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>{column.render('Header')}</th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody className='glassmorphism' {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => {
                  return <td {...cell.getCellProps()}>{cell.render('Cell')}</td>;
                })}
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

export default TokenTable;
