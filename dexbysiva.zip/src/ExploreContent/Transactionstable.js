// import React, { useState, useEffect } from 'react';
// import { Table } from 'react-bootstrap';
// import "../Assets/CSS/tokens.css"
// const YourComponent = () => {
//   // State to store data from the API
//   const [tableData, setTableData] = useState([]);

//   // Effect to fetch data from the API
//   useEffect(() => {
//     // Replace 'apiurl' with the actual endpoint of your API
//     fetch('apiurl')
//       .then(response => response.json())
//       .then(data => setTableData(data))
//       .catch(error => console.error('Error fetching data:', error));
//   }, []);

//   return (
//     <div className="container mt-1 mb-5 p-0 table-responsive table-container" style={{ borderRadius: '15px' }}>
//       <Table className="table  mb-0 p-5 " striped bordered hover>
//         <thead>
//           <tr className="border-bottom thead-background">
//             <th>
//               <img src="/images/volumearrow.png" alt="" style={{ height: '20px', width: '20px' }} /> Time
//             </th>
//             <th>Type</th>
//             <th>USD</th>
//             <th>Token amount</th>
//             <th>Token amount</th>
//             <th>Wallet</th>
//           </tr>
//         </thead>
//         <tbody className='glassmorphism'>
//           {tableData.map((rowData, index) => (
//             <tr key={index}>
//               <td>{rowData.time}</td>
//               <td>{rowData.type}</td>
//               <td>{rowData.usd}</td>
//               <td>
//                 <img src="/images/up.png" className="tokenimg" alt="" /> {rowData.tokenAmountUp}
//               </td>
//               <td>
//                 <img src="/images/down.png" className="tokenimg" alt="" /> {rowData.tokenAmountDown}
//               </td>
//               <td>{rowData.wallet}</td>
//               <td>
//                 <img src="/images/downgraph.png" width="124px" height="24px" alt="Graph 1" />
//               </td>
//             </tr>
//           ))}
//         </tbody>
//       </Table>
//     </div>
//   );
// };

// export default YourComponent;
import React, { useState, useEffect } from 'react';
import { useTable } from 'react-table';
import { Table } from 'react-bootstrap';
import "../Assets/CSS/tokens.css"

const YourComponent = () => {
  // State to store data from the API
  const [tableData, setTableData] = useState([]);

  // Effect to fetch data from the API
  useEffect(() => {
    // Replace 'apiurl' with the actual endpoint of your API
    fetch('apiurl')
      .then(response => response.json())
      .then(data => setTableData(data))
      .catch(error => console.error('Error fetching data:', error));
  }, []);

  // Define columns
  const columns = [
    {
      Header: () => (
        <div>
          <img src="/images/volumearrow.png" alt="" style={{ height: '20px', width: '20px' }} /> Time
        </div>
      ),
      accessor: 'time',
    },
    { Header: 'Type', accessor: 'type' },
    { Header: 'USD', accessor: 'usd' },
    {
      Header: 'Token amount',
      accessor: 'tokenAmountUp',
      Cell: ({ value }) => (
        <div>
          <img src="/images/up.png" className="tokenimg" alt="" /> {value}
        </div>
      ),
    },
    {
      Header: 'Token amount',
      accessor: 'tokenAmountDown',
      Cell: ({ value }) => (
        <div>
          <img src="/images/down.png" className="tokenimg" alt="" /> {value}
        </div>
      ),
    },
    { Header: 'Wallet', accessor: 'wallet' },
    {
      Header: '',
      accessor: 'graph',
      Cell: () => (
        <img src="/images/downgraph.png" width="124px" height="24px" alt="Graph 1" />
      ),
    },
  ];

  // Initialize react-table instance
  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable({ columns, data: tableData });

  return (
    <div className="container mt-1 mb-5 p-0 table-responsive table-container" style={{ borderRadius: '15px' }}>
      <Table className="table  mb-0 p-5 " striped bordered hover {...getTableProps()}>
        <thead>
          {headerGroups.map(headerGroup => (
            <tr {...headerGroup.getHeaderGroupProps()} className="border-bottom thead-background">
              {headerGroup.headers.map(column => (
                <th {...column.getHeaderProps()}>
                  {column.render('Header')}
                </th>
              ))}
            </tr>
          ))}
        </thead>
        <tbody className='glassmorphism' {...getTableBodyProps()}>
          {rows.map(row => {
            prepareRow(row);
            return (
              <tr {...row.getRowProps()}>
                {row.cells.map(cell => (
                  <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                ))}
              </tr>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

export default YourComponent;
