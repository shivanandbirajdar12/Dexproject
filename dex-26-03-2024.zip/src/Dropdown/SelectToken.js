import React,{useState} from 'react';
import cross from '../Assets/images2/radix-icons_cross-2.svg'
import PopularToken from './PopularToken';


const SelectToken = () => {
    const [showModal,setShowModal]=useState(false);

    const closeModal=()=>{
        setShowModal(false);
    }


    return (
        <>
            <div className='gnwYND bFCsHr'>
                <div className='hfXcaM kMkmMS'>
                    <div className='cPCYrp'>
                        <div style={{fontSize:'20px',color:'#b1b1b1'}}>select a token</div>
                        <img src={cross} style={{ height: '24px', width: '24px' }} onClick={closeModal} alt='' />
                    </div>
                    <div className='kdYshZ dKubqp'>
                        <input type="text" id="token-search-input" placeholder="Search name or paste address"  className=" hTynGq" />
                        <button className="sc-aXZVg bbWEFp lmdAXV kjpUwf">
                            <img
                                src="./images/sprint.png"
                                height="23px"
                                width="23px"
                                alt=""
                            />
                            <img
                                src="/images/dropdown.png"
                                height="23px"
                                width="23px"
                                alt=""
                            />
                        </button>
                    </div>
                    <div className='fxVDAj kdYshZ dKubqp'>
                        <div className='crYogb'>
                            <img src="./images/sprint.png" height="23px" width="23px" alt="" />
                            <span>MATIC</span>
                        </div>
                        <div className='crYogb'>
                            <img src="./images/sprint.png" height="23px" width="23px" alt="" />
                            <span>WETH</span>
                        </div>
                        <div className='crYogb'>
                            <img src="./images/sprint.png" height="23px" width="23px" alt="" />
                            <span>USDC</span>
                        </div>
                    </div>
                    <div className='fxVDAj kdYshZ dKubqp'>
                        <div className='crYogb'>
                            <img src="./images/sprint.png" height="23px" width="23px" alt="" />
                            <span>DAI</span>
                        </div>
                        <div className='crYogb'>
                            <img src="./images/sprint.png" height="23px" width="23px" alt="" />
                            <span>USDT</span>
                        </div>
                        <div className='crYogb'>
                            <img src="./images/sprint.png" height="23px" width="23px" alt="" />
                            <span>WBTC</span>
                        </div>
                    </div>
                </div>
                <div className='hfXcaM kMkmMS scrollbar' >
                    <div className=' text-light'>
                        Popular tokens
                    </div>
                    <div>
                    <PopularToken option='1Inch'/>
                    <PopularToken option='Aave'/>
                    <PopularToken option='Arcblock'/>
                    <PopularToken option='Alchemypay'/>
                    <PopularToken option='Ambire Adex'/>
                    <PopularToken option='Aergo'/>
                    <PopularToken option='agEur'/>
                    <PopularToken option='BigTime'/>
                    </div>
                </div>
            </div>
        </>
    );
}

export default SelectToken;
