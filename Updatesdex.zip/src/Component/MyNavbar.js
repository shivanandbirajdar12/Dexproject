import React, { useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import Navbar from 'react-bootstrap/Navbar';
import Nav from 'react-bootstrap/Nav';

import Logo from '../Assets/images2/logo ts.png'
import '../Assets/CSS/nav.css';
import '../Assets/CSS/offcanvas.css';
import NetworkOverlay from '../Dropdown/NetworkOverlay';
import NavDropdown from '../Dropdown/NavDropdown';

const MyNavbar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [isOpen1, setIsOpen1] = useState(false);
    const location = useLocation();

    const toggleDropdown = () => {
        setIsOpen(!isOpen);
    };

    const toggleDropdown1 = () => {
        setIsOpen1(!isOpen1);
    };

    const imageStyles = {
        height: '23px',
        width: '23px',
    };

    return (
        <div className='header_wrapper sticky-top'>
            <Navbar bg=" px-5" expand="lg" >
                <Navbar.Brand as={Link} to="/">
                    <img src={Logo} height="30px" width="30px"  alt="" />
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" className='bg-light' />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className="me-auto">
                        <NavLink to="/home" className="nav-link ms-2" activeClassName="active">Swap</NavLink>
                        <NavLink to="/explore" className="nav-link ms-2" activeClassName="active">Explore</NavLink>
                        <NavLink to="/analytics" className="nav-link ms-2" activeClassName="active">Analytics</NavLink>
                        <NavLink to="/pool" className="nav-link ms-2" activeClassName="active">Pool</NavLink>
                        <Link to="#" className="nav-link ms-2" onClick={toggleDropdown1}><img src="/images/dropdown.png" className="icons" alt="" /></Link>
                        {isOpen1 && <NavDropdown />}
                    </Nav>
                    <form className="d-flex ">
                        <div className="searchbar text-center">
                            <img src="/images/search.png" className="color-change-image ms-3" style={{ height: '23px', width: '23px' }} alt="" />
                            <input type="search" placeholder="Search Tokens and NFTs Collections" aria-label="Search" />
                            <img src="/images/forward.png" style={{ height: '20px', width: '20px' }} className="me-3" alt="" />
                        </div>
                    </form>
                </Navbar.Collapse>
                <div className="d-flex align-items-center">
                    <button id="selectedOptionBtn" type="button" className="btnGroupDrop1" onClick={toggleDropdown} >
                        <img src="/images/sprint.png" className="ms-2" style={imageStyles} alt="" />
                        <span className="icons"><img src="/images/dropdown.png" alt='' style={imageStyles} /></span>
                    </button>
                    {isOpen && <NetworkOverlay />}
                    <button className="connect-button1 px-4 ms-3"  >
                        <b className='connect1 '>Connect</b>
                    </button>
                </div>
            </Navbar>
        </div>
    );
};

export default MyNavbar;
