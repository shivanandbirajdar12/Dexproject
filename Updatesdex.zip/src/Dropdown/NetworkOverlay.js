import React, { useState } from 'react'
import './network.css'
import group1 from '../Assets/images2/Layer_x0020_1.png'
import tennisicon from '../Assets/images2/teenyicons_tick-solid.png'
const NetworkOverlay = () => {
    
    return (
        <>
            <div className="network-overlay">
                <div className="network-parent">
                    <div className="networks-parent">
                         <img className="networks-icon" alt="" src={group1} />
                        <div className="ethereum">Ethereum</div>
                    </div>
                    <img className="teenyiconstick-solid" alt="" src={tennisicon} />
                </div>
                <div className="network-overlay-inner">
                    <div className="networks-parent">
                        <img className="networks-icon1" alt="" src="NETWORKS.svg" />
                        <div className="ethereum">Arbitrum</div>
                    </div>
                </div>
                <div className="network-overlay-inner">
                    <div className="networks-parent">
                        <img className="networks-icon" alt="" src="NETWORKS.svg" />
                        <div className="ethereum">Optimism</div>
                    </div>
                </div>
                <div className="network-overlay-inner">
                    <div className="networks-parent">
                        <img className="networks-icon" alt="" src="NETWORKS.svg" />
                        <div className="ethereum">Polygon</div>
                    </div>
                </div>
                <div className="network-overlay-inner">
                    <div className="networks-parent">
                        <img className="networks-icon" alt="" src="NETWORKS.svg" />
                        <div className="ethereum">BNB Chain</div>
                    </div>
                </div>
                <div className="network-overlay-inner">
                    <div className="networks-parent">
                        <img className="networks-icon" alt="" src="NETWORKS.svg" />
                        <div className="ethereum">Avalanche</div>
                    </div>
                </div>
               
            </div>
        </>
    )
}

export default NetworkOverlay
