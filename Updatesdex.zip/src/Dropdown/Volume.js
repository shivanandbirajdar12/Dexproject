import React from 'react'
import './volume.css'
const Volume = () => {

    return (
        <>
            <div className="d-volume">
                <div className="d-volume-inner">
                    <div className="h-volume-wrapper">
                        <div className="h-volume">1H volume</div>
                    </div>
                </div>
                <div className="volume-parent">
                    <div className="h-volume-wrapper">
                        <div className="h-volume">1D volume</div>
                    </div>
                    <img className="teenyiconstick-solid" alt="" src="teenyicons:tick-solid.svg" />
                </div>
                <div className="d-volume-child">
                    <div className="h-volume-wrapper">
                        <div className="h-volume">1W volume</div>
                    </div>
                </div>
                <div className="d-volume-child">
                    <div className="h-volume-wrapper">
                        <div className="h-volume">1M volume</div>
                    </div>
                </div>
                <div className="d-volume-child">
                    <div className="h-volume-wrapper">
                        <div className="h-volume">1Y volume</div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default Volume
